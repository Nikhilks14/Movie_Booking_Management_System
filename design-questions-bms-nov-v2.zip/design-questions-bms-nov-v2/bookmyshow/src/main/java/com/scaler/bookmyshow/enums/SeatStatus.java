package com.scaler.bookmyshow.enums;

public enum SeatStatus {
    BOOKED,
    AVAILABLE,
    LOCKED,
}
