package com.scaler.bookmyshow.enums;

public enum MovieFeature {
    DOLBY,
    TWO_DIM,
    THREE_DIM
}
