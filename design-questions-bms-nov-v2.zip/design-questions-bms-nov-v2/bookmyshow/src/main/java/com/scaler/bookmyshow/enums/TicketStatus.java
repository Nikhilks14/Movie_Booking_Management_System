package com.scaler.bookmyshow.enums;

public enum TicketStatus {
    DONE,
    PENDING,
    CANCELLED
}
