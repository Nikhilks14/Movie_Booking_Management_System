package com.scaler.bookmyshow.enums;

public enum PaymentStatus {
    DONE,
    PENDING,
    FAILED
}
