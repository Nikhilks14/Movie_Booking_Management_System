package com.scaler.bookmyshow.enums;

public enum Language {
    HINDI,
    ENGLISH
}
