package com.scaler.bookmyshow.enums;

public enum PaymentMode {
    UPI,
    NET_BANKING,
    CASH
}
