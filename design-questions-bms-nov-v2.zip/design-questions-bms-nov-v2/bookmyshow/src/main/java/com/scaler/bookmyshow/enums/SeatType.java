package com.scaler.bookmyshow.enums;

public enum SeatType {
    VIP,
    PLATINUM,
    GOLD,
    SILVER,
}
